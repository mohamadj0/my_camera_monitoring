import cv2
import numpy as np
import streamlit as st

# مدل‌های تشخیص از کد جدید
def detect_blur_and_resolution_realtime(frame, blur_threshold=100.0, prev_resolution=None):
    current_resolution = frame.shape[:2]
    if prev_resolution and current_resolution != prev_resolution:
        resolution_changed = True
    else:
        resolution_changed = False
    prev_resolution = current_resolution

    # تبدیل تصویر به خاکستری
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # محاسبه تاری به روش تغییرات پیکسل‌ها
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    mean_laplacian = np.mean(np.abs(laplacian))

    # درصد تاری بر اساس مقدار لاپلاسیان
    blur_percentage = max(0, min(100, (mean_laplacian / blur_threshold) * 100))

    resolution_status = "Changed" if resolution_changed else "Stable"

    return blur_percentage, resolution_status, current_resolution, prev_resolution


def detect_occlusion(curr_frame, occlusion_threshold=0.95, black_threshold=50, white_threshold=205):
    gray = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    black_pixels = np.sum(blurred < black_threshold)
    white_pixels = np.sum(blurred > white_threshold)

    total_pixels = blurred.size
    black_ratio = black_pixels / total_pixels
    white_ratio = white_pixels / total_pixels

    if black_ratio > occlusion_threshold or white_ratio > occlusion_threshold or white_pixels == 0:
        return True, black_ratio, white_ratio
    else:
        return False, black_ratio, white_ratio


def detect_disconnection(curr_frame):
    if curr_frame is None or np.all(curr_frame == 0):
        return True
    return False


def detect_sudden_impact(prev_frame, curr_frame, threshold=50000):
    gray_prev = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)

    diff = cv2.absdiff(gray_prev, gray)
    _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)

    contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    total_area = sum(cv2.contourArea(c) for c in contours)

    if total_area > threshold:
        return True
    return False


def monitor_cameras(num_cameras, blur_threshold=100.0, impact_threshold=50000, camera_indices=None):
    camera_feeds = [cv2.VideoCapture(index) for index in camera_indices]
    
    prev_frames = [None] * num_cameras
    prev_resolutions = [None] * num_cameras

    frame_placeholders = [st.empty() for _ in range(num_cameras)]
    info_placeholders = [st.empty() for _ in range(num_cameras)]

    # نمایش زنده
    while True:
        for i, cap in enumerate(camera_feeds):
            ret, curr_frame = cap.read()
            
            if not ret:
                curr_frame = np.zeros((480, 640, 3), dtype=np.uint8)
                cv2.putText(curr_frame, f"Camera {i+1} Disconnected", (150, 240), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2, cv2.LINE_AA)
                blur_percentage, resolution_status, current_resolution, prev_resolutions[i] = None, None, None, None
                occlusion_status, impact_status, blur_status, disconnection_status = 'null', 'null', 'null', 'Disconnected'
            else:
                disconnection_status = "Disconnected" if detect_disconnection(curr_frame) else "Connected"
                is_occluded, black_ratio, white_ratio = detect_occlusion(curr_frame)
                occlusion_status = f"Black: {black_ratio:.2%}, White: {white_ratio:.2%}" if not is_occluded else "Yes"
                impact_detected = prev_frames[i] is not None and detect_sudden_impact(prev_frames[i], curr_frame, impact_threshold)
                impact_status = "Detected" if impact_detected else "Not Detected"
                blur_percentage, resolution_status, current_resolution, prev_resolutions[i] = detect_blur_and_resolution_realtime(
                    curr_frame, blur_threshold, prev_resolutions[i]
                )

                blur_status = "Detected" if blur_percentage and blur_percentage > 8 else "Not Detected"

            blur_style = f"<span style='color:red; font-size:36px;'><b>{blur_status}</b></span>" if blur_status == "Detected" else f"<span style='color:green; font-size:16px;'><b>{blur_status}</b></span>"
            impact_style = f"<span style='color:red; font-size:36px;'><b>{impact_status}</b></span>" if impact_status == "Detected" else f"<span style='color:green; font-size:16px;'><b>{impact_status}</b></span>"
            occlusion_style = f"<span style='color:red; font-size:36px;'><b>Yes</b></span>" if is_occluded else f"<span style='color:green; font-size:16px;'><b>{occlusion_status}</b></span>"
            disconnection_style = f"<span style='color:red; font-size:36px;'><b>{disconnection_status}</b></span>" if disconnection_status == "Disconnected" else f"<span style='color:green; font-size:16px;'><b>{disconnection_status}</b></span>"

            frame_placeholders[i].image(curr_frame, caption=f"Camera {i+1}", channels="BGR", width=200)
            info_placeholders[i].markdown(
                f"""
                **Camera {i+1}**  
                **Blur Status:** {blur_style} ({'N/A' if blur_percentage is None else f'{blur_percentage:.2f}%'})  
                **Resolution Status:** {resolution_status if resolution_status else 'N/A'}  
                **Occlusion Status:** {occlusion_style}  
                **Impact Status:** {impact_style}  
                **Connection Status:** {disconnection_style}  
                """,
                unsafe_allow_html=True,
            )

            prev_frames[i] = curr_frame
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    for cap in camera_feeds:
        cap.release()
    st.write("All cameras stopped.")
